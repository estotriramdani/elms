<!-- Begin Page Content -->
<div class="container-fluid">

    <p> Klik tombol di bawah untuk menuju menu yang ada di <strong>E-LMS</strong> untuk <strong>Guru</strong></p>
    <p>atau gunakan menu yang ada di sidebar</p>
    <p><a class="btn btn-primary" href="<?= base_url('guru/exambuilder'); ?>">Exam Builder</a></p>
    <p><a class="btn btn-primary" href="<?= base_url('guru/nilai'); ?>?kelas2=">Daftar Nilai Siswa</a></p>
    <p><a class="btn btn-primary" href="<?= base_url('guru/daftarsoal'); ?>?jenis_soal2=">Daftar Soal</a></p>

    

</div>
<!-- /.container-fluid -->

<!-- End of Main Content --> 