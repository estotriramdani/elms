
<?php
    $host="root";
    $user="root";
    $pwd="";
    $dbname="wpu_login";
    $kon=mysqli_connect($host,$user,$pwd,$dbname);
?>
